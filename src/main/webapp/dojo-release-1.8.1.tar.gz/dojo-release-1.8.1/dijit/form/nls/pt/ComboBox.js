//>>built
define("dijit/form/nls/pt/ComboBox",({previousMessage:"Opções anteriores",nextMessage:"Mais opções"}));
