//>>built
define("dijit/form/nls/tr/validate",({invalidMessage:"Girilen değer geçersiz.",missingMessage:"Bu değer gerekli.",rangeMessage:"Bu değer aralık dışında."}));
